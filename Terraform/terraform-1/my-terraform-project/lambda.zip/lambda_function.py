import boto3
import os
import json

sqs = boto3.client('sqs')

def lambda_handler(event, context):
    for record in event['Records']:
        body = record['body'] 
        try:
            # Envía el mensaje a SQS
            response = sqs.send_message(
                QueueUrl=os.environ['SQS_QUEUE_URL'], 
                MessageBody=body
            )
            print(f"Message sent to SQS: {response['MessageId']}")
        except Exception as e:
            print(f"Error sending message to SQS: {str(e)}")
            raise
    return {
        "statusCode": 200,
        "body": json.dumps("Messages processed and sent to SQS")
    }
