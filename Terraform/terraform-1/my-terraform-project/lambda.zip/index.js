const AWS = require('aws-sdk');
const sns = new AWS.SNS();

exports.handler = async (event) => {
    const message = {
        Subject: "New Notification",
        Message: "This is a notification from Lambda",
        TopicArn: process.env.SNS_TOPIC_ARN
    };

    try {
        const result = await sns.publish(message).promise();
        console.log(`Message sent to SNS: ${result.MessageId}`);
        return { statusCode: 200, body: "Message processed successfully" };
    } catch (error) {
        console.error("Error sending message to SNS", error);
        return { statusCode: 500, body: "Error processing message" };
    }
};
